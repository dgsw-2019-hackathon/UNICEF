﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Event : MonoBehaviour
{
    public void prologue()
    {
        Debug.Log("왜안됨");
        sceneLoad();
    }

    public void eventJanuary()//1월
    {
        sceneLoad();
    }

    public void eventFebruary() {//2월
        sceneLoad();
    }

    public void eventMarch() {//3월
        sceneLoad();
    }

    public void eventEndApril() {//끝 4월
        sceneLoad();
    }

    public void eventStartApril()//시작 4월
    {
        sceneLoad();
    }
    public void eventMay()//5월
    {
        sceneLoad();
    }
    public void eventJune()//6월
    {
        sceneLoad();
    }
    public void eventJuly()//7월
    {
        sceneLoad();
    }
    public void eventAugust()//8월
    {
        sceneLoad();
    }
    public void eventSeptember()//9월
    {
        sceneLoad();
    }
    public void eventOctober()//10월
    {
        sceneLoad();
    }

    public void eventNovember()//11월
    {
        sceneLoad();
    }

    public void eventDecember()//12월
    {
        sceneLoad();
    }

    public void sceneLoad()
    {
        SceneManager.LoadScene("MainScene");
    }
}
